package com.example.cherepanova_17_2

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import java.lang.System.load

class MainActivity : AppCompatActivity() {
    lateinit var login: EditText

    lateinit var pref: SharedPreferences;
    lateinit var edit: SharedPreferences.Editor;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        login = findViewById(R.id.pole)
    }

    fun tiktok(view: View) {
        if (login.text.toString().isNotEmpty()) {
            pref = getPreferences(MODE_PRIVATE);
            edit = pref.edit();

            edit.putString("login", login.text.toString());

            edit.apply();
        } else {
            val ohMyGod1 = AlertDialog.Builder(this)
                .setTitle("Ошибка")
                .setMessage("У вас есть незаполненные поля")
                .setPositiveButton("ok", null)
                .create()
                .show();
        }

        pref = getPreferences(MODE_PRIVATE);

        login.setText(pref.getString("login", ""));

        val ohMyGod2 = AlertDialog.Builder(this)
            .setTitle("Загрузка данных")
            .setMessage("Хотите добавить данные в зоголовки?")
            .setPositiveButton("Да") { _, _ ->
                login.setText("Ваш логин: ${pref.getString("login", "")}");
            }
            .setNegativeButton("Нет", null)
            .create()
            .show()
    }
}